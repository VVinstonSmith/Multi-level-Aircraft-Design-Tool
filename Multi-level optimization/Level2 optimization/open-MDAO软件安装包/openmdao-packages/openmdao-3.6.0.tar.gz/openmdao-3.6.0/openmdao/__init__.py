__version__ = '3.6.0'

INF_BOUND = 1.0E30
