Building and Viewing OpenMDAO Documentation:
--------------------------------------------

Building Docs
-------------

From the OpenMDAO/openmdao/docs level, type:

`make all`


Viewing Docs
------------

After the build completes, to view docs:

Open the file `OpenMDAO/openmdao/docs/_build/html/index.html` in a browser.
