__version__ = '3.9.2'

INF_BOUND = 1.0E30
