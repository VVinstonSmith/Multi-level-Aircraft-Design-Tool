"""Key OpenMDAO classes for parallel computing can be imported from here."""

from openmdao.vectors.petsc_vector import PETScVector
